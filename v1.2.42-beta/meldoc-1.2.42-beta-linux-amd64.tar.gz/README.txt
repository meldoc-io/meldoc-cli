meldoc CLI v1.2.42-beta
======================

Platform: linux/amd64

Installation:
-------------

1. Move the 'meldoc' binary to a directory in your PATH
2. Make it executable (Linux/macOS): chmod +x meldoc
3. Run: meldoc --help

Documentation:
--------------
https://github.com/meldoc-io/meldoc-cli.git

Support:
--------
https://github.com/meldoc-io/meldoc-cli.git/issues
