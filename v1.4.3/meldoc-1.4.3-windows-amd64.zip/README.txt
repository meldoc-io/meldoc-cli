meldoc CLI v1.4.3
======================

Platform: windows/amd64

Installation:
-------------

1. Move the 'meldoc' binary to a directory in your PATH
2. Make it executable (Linux/macOS): chmod +x meldoc
3. Run: meldoc --help

Documentation:
--------------
https://github.com/meldoc-io/meldoc-cli.git

Support:
--------
https://github.com/meldoc-io/meldoc-cli.git/issues
